import axios from "axios";

export default axios.create({
  baseURL: "http://65.0.129.68/api/v1/",
});
