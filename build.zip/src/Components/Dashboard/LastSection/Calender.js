import React from "react";
import Calendar from "react-calendar";
import "./Calender.css";

const Calender = () => {
  return <Calendar />;
};

export default Calender;
